import React from "react";

const OrderPage = () => {
  return <div>OrderPage</div>;
};

export default OrderPage;
