import { configureStore } from '@reduxjs/toolkit'
import counterReducer from './slides/counterSlide'
import userReducer from './slides/counterSlide'

export const store = configureStore({
  reducer: {
    counter: counterReducer,
    counter: userReducer
  }
})