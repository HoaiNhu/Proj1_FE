import ForgotPassword from "./pages/EnterEmail";
export default ForgotPassword;
